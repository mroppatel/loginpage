package com.edu;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class LoginServlet extends GenericServlet {

	@Override
	public void service(ServletRequest req, ServletResponse res)
			throws ServletException, IOException {
		res.setContentType("text/HTML");
		PrintWriter out = res.getWriter();
		String username = req.getParameter("uname");
		String password = req.getParameter("pass");
		String msg = "<html><head></head><body><center>";
		if(username!=null && password!=null && "admin".equals(username) && "1234".equals(password))
			msg += "Login <b>successfully</b>";
		else{
			msg += "<b>Invalid username or password </b>";
		    msg += "<a href='login.html'> <i>Try Again</i> </a>";	
		}
		
		msg += "</center></body></html>";
		out.println(msg);
	}

}
